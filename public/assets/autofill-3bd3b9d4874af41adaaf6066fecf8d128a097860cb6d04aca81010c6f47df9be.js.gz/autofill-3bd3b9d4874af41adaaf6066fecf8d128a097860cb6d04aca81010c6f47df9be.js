function suggest1() {
    document.getElementById('merchandise_name').value = "Tickets to My Show";
    document.getElementById('merchandise_price').value = "60";
    document.getElementById('merchandise_desc').value = "You get two tickets to see my show on January 15th @ 8:30pm at the Improv in Tempe. Just tell me where to send the tickets!";
}
function suggest2() {
    document.getElementById('merchandise_name').value = "Facebook Timeline Post from Me";
    document.getElementById('merchandise_price').value = "15";
    document.getElementById('merchandise_desc').value = "I'll post to your Facebook wall in the next week with an inspirational quote from my new book!";
}
function suggest3() {
    document.getElementById('merchandise_name').value = "@mention on Twitter";
    document.getElementById('merchandise_price').value = "20";
    document.getElementById('merchandise_desc').value = "I'll mention your Twitter username on my feed and respond to the thread.";
}
;
